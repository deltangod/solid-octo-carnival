-- Ankara Baddies initial Supabase schema.
-- Run in Supabase SQL Editor after creating a project.
-- IMPORTANT: configure RLS and server-side payment verification before production use.

create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique,
  description text,
  category text not null default 'Dresses',
  price_ngn integer not null check (price_ngn > 0),
  sizes text[] not null default array['XS','S','M','L','XL','XXL'],
  image_url text,
  badge text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  customer_name text not null,
  email text not null,
  phone text,
  shipping_address text not null,
  country text not null,
  notes text,
  items jsonb not null,
  total_amount integer not null check (total_amount >= 0),
  currency text not null default 'NGN',
  status text not null default 'pending_payment'
    check (status in ('pending_payment','paid','processing','shipped','delivered','cancelled','refunded')),
  payment_reference text unique,
  created_at timestamptz not null default now()
);

create table if not exists public.custom_orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  customer_name text not null,
  email text not null,
  garment text not null,
  size text not null,
  measurements text,
  description text not null,
  reference_url text,
  destination text not null,
  quoted_amount integer check (quoted_amount is null or quoted_amount >= 0),
  status text not null default 'quote_needed'
    check (status in ('quote_needed','awaiting_payment','paid','in_production','shipped','completed','cancelled')),
  payment_reference text unique,
  created_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  created_at timestamptz not null default now()
);

create table if not exists public.newsletter_subscribers (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  created_at timestamptz not null default now()
);

alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.custom_orders enable row level security;
alter table public.profiles enable row level security;
alter table public.newsletter_subscribers enable row level security;

-- Public storefront can read active products. Only trusted server/admin workflows should write.
create policy "Anyone can read active products"
  on public.products for select using (active = true);

-- Customers can read their own orders; never expose other customers' orders.
create policy "Customers can read own orders"
  on public.orders for select to authenticated using (auth.uid() = user_id);

create policy "Customers can read own custom orders"
  on public.custom_orders for select to authenticated using (auth.uid() = user_id);

create policy "Customers can read own profile"
  on public.profiles for select to authenticated using (auth.uid() = id);
create policy "Customers can update own profile"
  on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- Intentionally no public insert/update/delete policies for orders, custom_orders, products or subscribers.
-- Add a server/Edge Function that validates input, calculates prices from trusted product rows,
-- creates orders, initializes Paystack payments, verifies the provider callback/webhook, and updates status.
-- Never trust the browser's amount or a successful browser callback as proof of payment.
