-- Ankara Baddies Supabase schema (safe to re-run).
-- Run in Supabase: SQL Editor > New query > paste > Run.

create extension if not exists pgcrypto;

-- ---------- TABLES ----------
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique,
  description text,
  category text not null default 'Dresses',
  price_ngn integer not null check (price_ngn > 0),
  sizes text[] not null default array['XS','S','M','L','XL','XXL'],
  image_url text,
  badge text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  customer_name text not null,
  email text not null,
  phone text,
  shipping_address text not null,
  country text not null,
  notes text,
  items jsonb not null,
  total_amount integer not null check (total_amount >= 0),
  currency text not null default 'NGN',
  status text not null default 'pending_payment'
    check (status in ('pending_payment','paid','processing','shipped','delivered','cancelled','refunded')),
  payment_reference text unique,
  paid_at timestamptz,
  created_at timestamptz not null default now()
);
alter table public.orders add column if not exists paid_at timestamptz;

create table if not exists public.custom_orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  customer_name text not null,
  email text not null,
  garment text not null,
  size text not null,
  measurements text,
  description text not null,
  reference_url text,
  destination text not null,
  quoted_amount integer check (quoted_amount is null or quoted_amount >= 0),
  status text not null default 'quote_needed'
    check (status in ('quote_needed','awaiting_payment','paid','in_production','shipped','completed','cancelled')),
  payment_reference text unique,
  created_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  is_admin boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.profiles add column if not exists is_admin boolean not null default false;

create table if not exists public.newsletter_subscribers (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  created_at timestamptz not null default now()
);

create table if not exists public.site_settings (
  key text primary key,
  value text not null default '',
  updated_at timestamptz not null default now()
);

-- ---------- HELPERS ----------
create or replace function public.is_admin()
returns boolean language sql security definer stable set search_path = public as $$
  select coalesce((select is_admin from public.profiles where id = auth.uid()), false)
$$;

-- Create a profile automatically for every new signup.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, new.raw_user_meta_data->>'full_name')
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

insert into public.profiles (id) select id from auth.users on conflict (id) do nothing;

-- ---------- ROW LEVEL SECURITY ----------
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.custom_orders enable row level security;
alter table public.profiles enable row level security;
alter table public.newsletter_subscribers enable row level security;
alter table public.site_settings enable row level security;

-- Payment details are shown to customers at checkout, so everyone can read; only admins can change.
drop policy if exists "Anyone can read settings" on public.site_settings;
create policy "Anyone can read settings" on public.site_settings for select using (true);
drop policy if exists "Admins manage settings" on public.site_settings;
create policy "Admins manage settings" on public.site_settings for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- Products: public can read active ones; admins can do everything.
drop policy if exists "Anyone can read active products" on public.products;
create policy "Anyone can read active products" on public.products for select using (active = true);
drop policy if exists "Admins manage products" on public.products;
create policy "Admins manage products" on public.products for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- Orders: customers read their own; admins read and update all.
-- Orders are CREATED only by the Netlify function (service role), never by the browser.
drop policy if exists "Customers can read own orders" on public.orders;
create policy "Customers can read own orders" on public.orders for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Admins read orders" on public.orders;
create policy "Admins read orders" on public.orders for select to authenticated using (public.is_admin());
drop policy if exists "Admins update orders" on public.orders;
create policy "Admins update orders" on public.orders for update to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "Customers can read own custom orders" on public.custom_orders;
create policy "Customers can read own custom orders" on public.custom_orders for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Admins read custom orders" on public.custom_orders;
create policy "Admins read custom orders" on public.custom_orders for select to authenticated using (public.is_admin());
drop policy if exists "Admins update custom orders" on public.custom_orders;
create policy "Admins update custom orders" on public.custom_orders for update to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- Profiles: users read/update their own, but can NEVER change is_admin.
drop policy if exists "Customers can read own profile" on public.profiles;
create policy "Customers can read own profile" on public.profiles for select to authenticated using (auth.uid() = id);
drop policy if exists "Customers can update own profile" on public.profiles;
create policy "Customers can update own profile" on public.profiles for update to authenticated
  using (auth.uid() = id) with check (auth.uid() = id);
revoke update on public.profiles from authenticated;
grant update (full_name, phone) on public.profiles to authenticated;

drop policy if exists "Admins read subscribers" on public.newsletter_subscribers;
create policy "Admins read subscribers" on public.newsletter_subscribers for select to authenticated using (public.is_admin());

-- ---------- STORAGE (product photos) ----------
insert into storage.buckets (id, name, public) values ('product-images', 'product-images', true)
  on conflict (id) do nothing;
drop policy if exists "Public read product images" on storage.objects;
create policy "Public read product images" on storage.objects for select using (bucket_id = 'product-images');
drop policy if exists "Admins upload product images" on storage.objects;
create policy "Admins upload product images" on storage.objects for insert to authenticated
  with check (bucket_id = 'product-images' and public.is_admin());
drop policy if exists "Admins update product images" on storage.objects;
create policy "Admins update product images" on storage.objects for update to authenticated
  using (bucket_id = 'product-images' and public.is_admin());
drop policy if exists "Admins delete product images" on storage.objects;
create policy "Admins delete product images" on storage.objects for delete to authenticated
  using (bucket_id = 'product-images' and public.is_admin());

-- ---------- STARTER PRODUCTS ----------
insert into public.products (name, slug, description, category, price_ngn, badge) values
  ('The Zuri Midi','the-zuri-midi','A statement midi with a flattering waist.','Dresses',38500,'Bestseller'),
  ('The Kente Muse Set','the-kente-muse-set','A coordinated two-piece with big energy.','Sets',52000,'New drop'),
  ('Olive Bloom Dress','olive-bloom-dress','A soft silhouette with a bold print.','Dresses',42000,'Limited'),
  ('The Amara Top','the-amara-top','The top that makes simple plans feel special.','Tops',22000,'Easy favourite'),
  ('Sunday Best Set','sunday-best-set','A playful set made for being seen.','Sets',48500,'Baddie pick'),
  ('Sunset Wrap Dress','sunset-wrap-dress','Wrap, tie, and make the entrance.','Dresses',39500,'Just landed'),
  ('The Lagos Blouse','the-lagos-blouse','An Ankara staple with a polished finish.','Tops',19500,'Everyday luxe'),
  ('Pink Pepper Co-ord','pink-pepper-co-ord','For days when blending in is not the assignment.','Sets',55000,'Statement')
on conflict (slug) do nothing;

insert into public.site_settings (key, value) values
  ('bank_name', 'Your Bank'),
  ('account_number', '0000000000'),
  ('account_name', 'Ankara Baddies'),
  ('whatsapp_number', ''),
  ('payment_note', 'Use your order reference as the transfer narration.')
on conflict (key) do nothing;

-- ---------- MAKE YOURSELF ADMIN ----------
-- 1) Create an account on your site first. 2) Then run (with your email):
-- update public.profiles set is_admin = true where id = (select id from auth.users where email = 'you@example.com');
