# Ankara Baddies storefront

A responsive luxury/feminine storefront starter for a Nigerian Ankara fashion brand. It includes:
- Product grid, category filters, price sorting and size selection
- Shopping bag with quantity controls
- Custom order request form
- Checkout form
- Account UI
- Browser-only demo admin at `/?admin=1`
- Supabase schema for products, accounts, orders and custom orders
- Optional Supabase Auth/database and Paystack public-key hooks
- Netlify-ready static files

## Run it
Open `index.html` in a browser, or deploy the folder to Netlify. For best results, test using a local static server because browser security rules can differ when opening a file directly.

## Demo behaviour
Without credentials, products, demo accounts, cart, newsletter and demo orders use the current browser's `localStorage`. This is for preview/testing only. It is not shared across devices and is not a secure admin system. The sample product photos are abstract placeholders; use real product image URLs from your own catalog.

## Set up Supabase
1. Create a Supabase project.
2. Open **SQL Editor** and run `supabase-schema.sql`.
3. In `app.js`, set `CONFIG.supabaseUrl` and `CONFIG.supabaseAnonKey` using your project URL and publishable/anon key. Never use a `service_role` secret in frontend code.
4. Implement a server-side/Edge Function for order creation and payment verification. The frontend contains starter calls, not a complete production backend.
5. Configure account email confirmation and redirect URLs in Supabase Auth.

## Set up payments
The Paystack public key slot in `app.js` is only a starting point. Before accepting real payments, create a server-side endpoint/Edge Function that:
- calculates prices from trusted database product records, not browser totals;
- creates the order with a pending status;
- initializes Paystack using a secret key stored only server-side;
- verifies payment references with Paystack and handles webhooks idempotently;
- marks an order paid only after trusted verification.

Never put Paystack secret keys or Supabase service-role keys in `app.js`.

## Admin dashboard
Visit `/?admin=1`. This is a browser-local preview admin, not production authentication. Anyone who can access the URL can open it, and changes are saved only in that browser. Before launch, replace it with an authenticated admin route and enforce admin roles in the database/server. Product image uploads should use Supabase Storage or another storage provider with restricted upload permissions.

## Custom order workflow
The current form collects design notes, size/measurements, destination and an optional reference-image URL. The brand should review the request, send a quote, then collect payment through a verified payment flow. Do not automatically charge an unconfirmed custom order.

## Before launch checklist
- Replace placeholder product art with original product photos.
- Confirm actual sizes, prices, production timelines, returns policy and shipping rates.
- Add privacy policy, terms, shipping/returns page and contact details.
- Set up Supabase Auth, database policies, storage and admin roles.
- Build and test server-side Paystack initialization and verification.
- Test mobile layout, checkout, order emails and shipping destinations.
- Add a real customer support email and social links.
