# Ankara Baddies storefront

A responsive luxury/feminine storefront starter for a Nigerian Ankara fashion brand. It includes:
- Product grid, category filters, price sorting and size selection
- Shopping bag with quantity controls
- Custom order request form
- Checkout form
- Account UI
- Admin dashboard at `/?admin=1` (demo mode without Supabase)
- Supabase schema for products, accounts, orders and custom orders
- Supabase Auth/database/storage; bank-transfer checkout with WhatsApp proof of payment via Netlify Functions
- Netlify-ready static files

## Run it
Open `index.html` in a browser, or deploy the folder to Netlify. For best results, test using a local static server because browser security rules can differ when opening a file directly.

## Demo behaviour
Without credentials, products, demo accounts, cart, newsletter and demo orders use the current browser's `localStorage`. This is for preview/testing only. It is not shared across devices and is not a secure admin system. The sample product photos are abstract placeholders; use real product image URLs from your own catalog.

## Go live: backend setup (about 20 minutes)
**1. Supabase**
- Create a project, then SQL Editor > paste `supabase-schema.sql` > Run (safe to re-run).
- Project Settings > API: copy the **Project URL** and **anon/publishable key** into `CONFIG` at the top of `app.js`.
- Authentication > URL Configuration: set Site URL to your Netlify URL.
- Create an account on your site, then run this in the SQL Editor to make yourself admin:
  `update public.profiles set is_admin = true where id = (select id from auth.users where email = 'you@example.com');`

**2. Netlify environment variables** (Site configuration > Environment variables)
| Name | Value |
|---|---|
| `SUPABASE_URL` | your Project URL |
| `SUPABASE_SERVICE_ROLE_KEY` | service_role key (secret, server only) |

**3. Deploy**
Netlify Functions need a Git deploy (GitHub/GitLab/Bitbucket connected to Netlify) or the Netlify CLI (`netlify deploy --prod`). Plain drag-and-drop of the folder will not run the functions.

**4. Add your payment details**
Open `/?admin=1`, sign in, and fill in **Payment details** (bank, account number, account name, WhatsApp number). Changes show to customers immediately.

## How payment works
1. Customer checks out and the order is saved as `pending payment` with a reference like `AB-7K3MQ9XD`.
2. They see your bank details plus a **Send proof on WhatsApp** button with the order reference and amount pre-filled.
3. You match the reference in `/?admin=1` > Orders and change the status to **paid** (then processing, shipped, delivered).

## Security notes
- Prices always come from the database; the browser only sends product ids, sizes and quantities.
- Only admins (`is_admin`) can edit products, orders and payment details, enforced by database policies.
- Payment is confirmed by you manually, so always check your bank app before marking an order paid.
- Shipping fees are not added yet; totals equal the product subtotal.

## Custom order workflow
The current form collects design notes, size/measurements, destination and an optional reference-image URL. The brand should review the request, send a quote, then collect payment through a verified payment flow. Do not automatically charge an unconfirmed custom order.

## Before launch checklist
- Replace placeholder product art with original product photos.
- Confirm actual sizes, prices, production timelines, returns policy and shipping rates.
- Add privacy policy, terms, shipping/returns page and contact details.
- Place a test order end to end and check the WhatsApp message.
- Add order confirmation emails and shipping rates.
- Test mobile layout, checkout, order emails and shipping destinations.
- Add a real customer support email and social links.
